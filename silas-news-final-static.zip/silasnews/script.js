const stories=[
 {cat:'Nigeria',icon:'🇳🇬',title:'Nigeria news and public updates in one place',text:'A clean section for verified national developments and important announcements.',source:'Silas News Desk'},
 {cat:'Education',icon:'🎓',title:'Education and university updates',text:'Follow admissions, examinations, scholarships and opportunities for students.',source:'Silas News Desk'},
 {cat:'Technology',icon:'🤖',title:'AI and technology developments',text:'Understand major technology stories without complicated language.',source:'Silas News Desk'},
 {cat:'World',icon:'🌍',title:'Major world developments',text:'A space for important international stories and global events.',source:'Silas News Desk'},
 {cat:'Sports',icon:'⚽',title:'Sports stories and results',text:'Follow major football and sporting developments.',source:'Silas News Desk'},
 {cat:'Entertainment',icon:'🎬',title:'Entertainment and culture',text:'Movies, music, creators and culture updates.',source:'Silas News Desk'}
];
let active='All';
const categories=['All',...new Set(stories.map(s=>s.cat))];
function renderFilters(){document.getElementById('filters').innerHTML=categories.map(c=>`<button class="filter ${active===c?'active':''}" onclick="setCategory('${c}')">${c}</button>`).join('')}
function render(){renderFilters();const q=(document.getElementById('siteSearch')?.value||'').toLowerCase();const data=stories.filter(s=>(active==='All'||s.cat===active)&&(`${s.title} ${s.text} ${s.cat}`).toLowerCase().includes(q));document.getElementById('newsGrid').innerHTML=data.map((s,i)=>`<article class="card" onclick="showStory(${stories.indexOf(s)})"><div class="thumb">${s.icon}</div><div class="card-content"><span class="tag">${s.cat}</span><h3>${s.title}</h3><p>${s.text}</p><small>Silas News • Oct 5, 2026</small></div></article>`).join('');document.getElementById('empty').hidden=data.length>0}
function setCategory(c){active=c;render();document.getElementById('latest').scrollIntoView({behavior:'smooth'})}
function refreshNews(){document.getElementById('tickerText').textContent='News feed refreshed — ready for verified stories.';render()}
function toggleMenu(){document.getElementById('navlinks').classList.toggle('open')}
function toggleTheme(){document.body.classList.toggle('darkmode');localStorage.setItem('silasTheme',document.body.classList.contains('darkmode')?'dark':'light')}
function openSearch(){document.getElementById('searchModal').classList.add('show');document.getElementById('modalSearch').focus();updateModalResults('')}
function closeSearch(){document.getElementById('searchModal').classList.remove('show')}
function syncSearch(){const q=document.getElementById('modalSearch').value;document.getElementById('siteSearch').value=q;render();updateModalResults(q)}
function updateModalResults(q){const x=q.toLowerCase();const data=stories.filter(s=>`${s.title} ${s.text} ${s.cat}`.toLowerCase().includes(x));document.getElementById('modalResults').innerHTML=data.slice(0,5).map(s=>`<button class="result" onclick="showStory(${stories.indexOf(s)});closeSearch()"><b>${s.cat}</b><span>${s.title}</span></button>`).join('')}
function showStory(i){const s=stories[i];showArticle(s.title,`${s.text}\n\nSource: ${s.source||'Silas News Desk'}\nPublished: October 5, 2026`);}
function showArticle(title,body='Silas News is designed to make important updates easier to find, read and share.'){document.getElementById('articleTitle').textContent=title;document.getElementById('articleBody').textContent=body;document.getElementById('articleModal').classList.add('show')}
function closeArticle(){document.getElementById('articleModal').classList.remove('show')}
function askAI(){const q=document.getElementById('question').value.trim();const answer=document.getElementById('answer');if(!q){answer.textContent='Type a question first.';return}const ql=q.toLowerCase(); let reply='I can explain the stories published on this website. Try asking about Nigeria, education, technology, world news or sports.'; if(ql.includes('education')||ql.includes('jamb')||ql.includes('university')) reply='Education desk: Silas News can publish admissions, examination, scholarship and school updates here. Always check the original official announcement before acting on important information.'; else if(ql.includes('technology')||ql.includes('ai')) reply='Technology desk: this section is for clear explanations of important AI, apps, devices and digital-safety developments.'; else if(ql.includes('sport')||ql.includes('football')) reply='Sports desk: this section can carry football results, fixtures and major sporting stories added by the editor.'; else if(ql.includes('nigeria')) reply='Nigeria desk: this section is for important national developments and public announcements added by the editor.'; answer.textContent=reply;}
if(localStorage.getItem('silasTheme')==='dark')document.body.classList.add('darkmode');
render();
